// document.getElementById("count-el").innerText = 5

//Creame una variable que se llame mi edad. Pon tu Edad.
//Imprime por consola el valor de tu edad.

//let edad = 19
//console.log("Mi edad es de " + edad)

//Calculame tu edad en años de perro
// let ratio = 7
// let miEdad = 19
// let edadPerro = miEdad * ratio
// console.log("Mis años en perro son " + edadPerro);

// let cuentas = 5
// cuentas = cuentas + 2
// cuentas = cuentas - 100
// console.log(cuentas)

/* Creame una variable que se llame bonusPoints.
Inicializala en 50
Increméntala en 100
Decreméntala en 25
Increméntala en 30
En cada incremento/decremento, imprime por consola el resultado
*/

// let bonusPoints = 50
// console.log(bonusPoints)
// bonusPoints = bonusPoints + 100
// console.log(bonusPoints)
// bonusPoints = bonusPoints -25
// console.log(bonusPoints)
// bonusPoints = bonusPoints + 30
// console.log(bonusPoints)

/*
Pseudocodigo
Inicialice el conteo de la app en 0
Lean los clicks con el boton de incremento
Incremento la varianle de conteo de manera que cuando click, sumo gente
Cambio el recuento en el HTML para reflajar el nuevo recuento de personas
*/
let countEl = document.getElementById("count-el")
let saveEl = document.getElementById("save-el")
let count = 0
function increment() {
    console.log("El botón ha sido pulsado");
    count += 1
    countEl.textContent = count //innerText da fallos con formato
}
increment()

function decrement() {
    console.log("El botón ha sido pulsado");
    count -= 1
    countEl.textContent = count
}
decrement()

function save() {
    let countStr = count + " - "
    saveEl.textContent += countStr
    countEl.textContent = 0
    count = 0
}

// Hazme una funcion que se llame cunata atras y que haga una cuenta atras del 5 al 1
// let tiempo = 5
// function cuentaAtras() {
//     tiempo = tiempo - 1
//     console.log(tiempo);
// }
// cuentaAtras()

// function cuentaAtras2() {
//     console.log(5);
//     console.log(4);
//     console.log(3);
//     console.log(2);
//     console.log(1);
// }
// cuentaAtras2()

/*
Cuentame los minutos totales en los que un piloto da vueltas a un ciercuito.
Tu pilotao va a dar de 3 a 5 vueltas, tu eliges.
La funcion tiene que calcular el tiempo TOTAL que ha gastado en dar esas vueltas

PISTA:
3 variables
1 funcion (1 variable + console.log)
llamda funcion
*/

// let vuelta1 = 2.4
// let vuelta2 = 5.1
// let vuelta3 = 4.4

// function tiempoVueltas() {
//     let tiempototal = vuelta1 + vuelta2 + vuelta3
//     console.log("Ha tardado en total " + tiempototal + " minutos.");
// }

// tiempoVueltas()


/*
Creame una funcion que incrementa su valor en 1 y que sea ejecutada 3 veces
Trabaja con una variable que previamente se llame vueltasCompletadas
*/
// let vueltasCompletadas = 0
// function vueltas() {
//     vueltasCompletadas = vueltasCompletadas + 1
//     console.log("El numero de vueltas completadas es de " + vueltasCompletadas);
// }
// vueltas()
// vueltas()
// vueltas()

// let username = "paco"
// console.log(username)

/*
2. Tabla de Multiplicar: Crea una funciÃ³n llamada tablaMultiplicar que reciba 
un nÃºmero. La funciÃ³n debe imprimir la tabla de multiplicar de ese nÃºmero del 
1 al 10 usando un bucle. Por ejemplo, si el nÃºmero es 5, debe imprimir "5 x 1 = 5",
"5 x 2 = 10", etc. Normalmente se hace con un for, pero no sabemos hacerlo. 
Si sabes hacerlo con un for, hazlo.
*/

// let tabla = 5
// console.log(tabla + " x 1 = "+ tabla*1);
// console.log(tabla + " x 2 = "+ tabla*2);
// console.log(tabla + " x 3 = "+ tabla*3);
// console.log(tabla + " x 4 = "+ tabla*4);
// console.log(tabla + " x 5 = "+ tabla*5);
// console.log(tabla + " x 6 = "+ tabla*6);
// console.log(tabla + " x 7 = "+ tabla*7);
// console.log(tabla + " x 8 = "+ tabla*8);
// console.log(tabla + " x 9 = "+ tabla*9);
// console.log(tabla + " x 10 = "+ tabla*10);

/*
3. Convertidor de Temperatura: Declara una funciÃ³n convertirCelsiusAFahrenheit
que tome una temperatura en Celsius y la convierta a Fahrenheit, usando la fÃ³rmula
\( F = C \times 9/5 + 32 \). La funciÃ³n debe imprimir el resultado en la consola.
Usa constantes, no variables. Aunque no lo hayamos dado, mira como declarar una
constante en JS.
*/


// function fahrenheitCelsius(celsius) { 
//     const fahrenheit = (celsius * (9/5) + 32)
//     console.log(celsius + "ºC pasado a fahrenheit es: "+ fahrenheit + "F")
// }
// fahrenheitCelsius(20)

/*
4. Calculadora de IVA: Escribe una funciÃ³n calcularIVA que reciba el precio de un 
producto como argumento. La funciÃ³n debe calcular el 21% de IVA sobre ese precio y 
retornar el precio final incluido el IVA. Luego, imprime este precio final en la 
consola.
*/

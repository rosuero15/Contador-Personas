let countEl = document.getElementById("count-el")
let saveEl = document.getElementById("save-el")
let dineroEl = document.getElementById("dinero-el")
let count = 0
let dineroTotal = 0
function increment() {
    //console.log("El botón ha sido pulsado");
    count += 1
    countEl.textContent = count //innerText da fallos con formato
    dineroTotal += 2
    dineroEl.textContent = dineroTotal + '€'
}

function decrement() {
    //console.log("El botón ha sido pulsado");
    if (count === 0) {
        alert("NO SE PUEDEN TENER PERSONAS NEGATIVAS")
    } else {
        count -= 1
        countEl.textContent = count
    }

}

function save() {
    let countStr = count + " - "
    saveEl.textContent += countStr
    countEl.textContent = 0
    count = 0
}
function contarGrupos() {
    let grupos = Number(prompt("Dime un numero"))
    if (isNaN(grupos)) {
        alert("¡INSERTE UN NUMERO!")
    } else {
        if (grupos < 10) {
            alert("Tiene que haber un mínimo de 10 personas para considerarse grupo")
        } else {
            if (grupos + count < 0) {
                alert("NO SE PUEDEN TENER PERSONAS NEGATIVAS")
            } else {
                count = count + grupos
                countEl.textContent = count
                dineroTotal += 1.5*grupos
                dineroEl.textContent = dineroTotal + '€'
            }
        }
    }
}